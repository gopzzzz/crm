

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Add Employee</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            


              <div class="row">
                
               

                <!-- Form controls -->
                <div class="col-md-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Register New Employees</h5>
                    <div class="card-body">
                    <form action="<?php echo e(route('createnewemployee')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                 
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Employee Name</label>
                        <input
                          type="text"
                          class="form-control"
                          id="exampleFormControlInput1"
                          placeholder="Enter your name"
                          name="employee_name"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Designation</label>
                        <input
                          type="text"
                          class="form-control"
                          id="exampleFormControlInput1"
                          placeholder="Enter your Designation"
                          name="designation"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">Email</label>
                        <input
                          class="form-control"
                          type="email"
                          id="exampleFormControlReadOnlyInput1"
                          placeholder="example@gmail.com"
                          name="email"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Phone Number</label>
                        <input
                          type="number"
                          name="phone_number"
                          class="form-control"
                          placeholder="Enter your phone number"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Date of Birth</label>
                        <input
                          type="date"
                          name="dob"
                          class="form-control"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Address</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1"  placeholder="Enter your Address" rows="3" name="address"></textarea>
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1"  class="form-label">Password</label>
                        <input
                          class="form-control"
                          type="password"
                           placeholder="Enter a strong password (min 8 characters)"
                          id="exampleFormControlReadOnlyInput1"
                          name="password"
                        />
                      </div>
                    
                      <div>
                      <button type="submit" class="btn btn-primary">Create New Employee</button>
                      </div>
</form>
                    </div>
                  </div>
                </div>

                <!-- Input Sizing -->
                

                <!-- Default Checkboxes and radios & Default checkboxes and radios -->
                

                
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/softotql/data.softocoder.com/resources/views/employee/addemployee.blade.php ENDPATH**/ ?>