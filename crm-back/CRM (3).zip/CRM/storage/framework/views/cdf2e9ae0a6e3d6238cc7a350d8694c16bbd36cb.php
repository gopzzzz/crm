

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Add Leads</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <?php echo e($message); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <h5 class="card-header">Register New Enquiries</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('createnewlead')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Lead Type <span class="text-danger fw-bold">*</span></label>
                                <select class="form-select" name="leadtype">
                                    <option selected disabled>Open this select menu</option>
                                    <?php $__currentLoopData = $leadtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->lead_type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Assigned User</label>
                                <select class="form-select" name="assigneduser">
                                    <option selected disabled>Open this select menu</option>
                                    <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($typee->userid); ?>"><?php echo e($typee->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="fullname" placeholder="Enter your name" />
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="example@gmail.com" />
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Phone Number <span class="text-danger fw-bold">*</span></label>
                                <input type="number" class="form-control" name="phonenumber" placeholder="Enter your phone number" />
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Check In</label>
                                <input type="date" class="form-control" name="checkin" />
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Check Out</label>
                                <input type="date" class="form-control" name="checkout" />
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Number of Guests</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <input name="adults" type="number" class="form-control" placeholder="Adults" min="0" />
                                </div>
                                <div class="col-md-4">
                                    <input name="children" type="number" class="form-control" placeholder="Children" min="0" />
                                </div>
                                <div class="col-md-4">
                                    <input name="infants" type="number" class="form-control" placeholder="Infants" min="0" />
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Room Type</label>
                                <select class="form-select" name="roomtype">
                                    <option selected disabled>Open this select menu</option>
                                    <?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rooms->id); ?>"><?php echo e($rooms->room_type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Addons</label>
                                <select class="form-select" name="purpose">
                                    <option selected disabled>Open this select menu</option>
                                    <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ad->id); ?>"><?php echo e($ad->extras); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Lead Status</label>
                                <select class="form-select" name="status">
                                    <option selected disabled>Open this select menu</option>
                                    <option value="1">Hot</option>
                                    <option value="2">Warm</option>
                                    <option value="3">Cold</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Booking Status</label>
                                <select class="form-select" name="sales_status">
                                    <option selected disabled>Open this select menu</option>
                                    <option value="1">Converted</option>
                                    <option value="2">Proccessing</option>
                                    <option value="3">Dead</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Task Status</label>
                                <select class="form-select" name="task_status">
                                    <option selected disabled>Open this select menu</option>
                                    <option value="1">Pending</option>
                                    <option value="2">Completed</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Reminder Date</label>
                                <input type="date" class="form-control" name="reminder_date" />
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Reminder Notes</label>
                                <textarea class="form-control" name="note" rows="3"></textarea>
                            </div>
                        </div>

                        <div>
                            <button type="submit" class="btn btn-primary">Create New Lead</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRM\resources\views/admin/addlead.blade.php ENDPATH**/ ?>