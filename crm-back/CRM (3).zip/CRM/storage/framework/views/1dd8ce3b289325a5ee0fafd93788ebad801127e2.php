

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Edit Leads</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="row">
                 <!-- Form controls -->
                <div class="col-md-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Edit Enquiries</h5>
                    <div class="card-body">
                    <form action="<?php echo e(route('editlead')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($leads->id); ?>">

                    <div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Lead Type</label><small>
                     <span class="text-danger fw-bold" style="font-size: 1.2em;">*</span>
                    </small>
    <select class="form-select" name="leadtype" id="exampleFormControlSelect1" aria-label="Default select example">
        <option disabled <?php echo e($leads->lead_type ? '' : 'selected'); ?>>Open this select menu</option>
        <?php $__currentLoopData = $leadtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>" <?php echo e($leads->lead_type == $type->id ? 'selected' : ''); ?>>
                <?php echo e($type->lead_type); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                        <input
                          type="text"
                          class="form-control"
                          id="exampleFormControlInput1"
                          value="<?php echo e($leads->full_name ?? ''); ?>"
                          name="full_name"
                          placeholder="enter your name"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">Email</label>
                        <input
                          class="form-control"
                          type="email"
                          placeholder="enter your Email"

                          id="exampleFormControlReadOnlyInput1"
                          value="<?php echo e($leads->email ?? ''); ?>"
                          name="email"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Phone Number</label>
                        <small>
                     <span class="text-danger fw-bold" style="font-size: 1.2em;">*</span>
                    </small>
                        <input
                          type="number"
                          name="phone_number"
                          value="<?php echo e($leads->phone_number ?? ''); ?>"
                          class="form-control"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Assigned User</label>
    <select class="form-select" name="assigneduser" id="exampleFormControlSelect1" aria-label="Default select example">
    <option disabled <?php echo e($leads->name ? '' : 'selected'); ?>>Open this select menu</option>
        <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>" <?php echo e($leads->name == $type->id ? 'selected' : ''); ?>>
                <?php echo e($type->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Check In</label>
                        <input
                          type="date"
                          name="checkin"
                          class="form-control"
                          value="<?php echo e($leads->checkin ?? ''); ?>"

                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Check Out</label>
                        <input
                          type="date"
                          name="checkout"
                          class="form-control"
                          value="<?php echo e($leads->checkout ?? ''); ?>"

                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
  <label class="form-label">Number of Guests</label>
  
  <div class="row">
    <div class="col">
      <input
        name="adults"
        type="number"
        class="form-control"
        value="<?php echo e($leads->numberofguest ?? ''); ?>"

        placeholder="Adults"
        min="0"
      />
    </div>
    <div class="col">
      <input
        name="children"
        type="number"
        class="form-control"
        value="<?php echo e($leads->child ?? ''); ?>"

        placeholder="Children"
        min="0"
      />
    </div>
    <div class="col">
      <input
        name="infants"
        type="number"
        class="form-control"
        value="<?php echo e($leads->infant ?? ''); ?>"

        placeholder="Infants"
        min="0"
      />
    </div>
  </div>
</div>


<div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Room Type</label>
    <select class="form-select" name="roomtype" id="exampleFormControlSelect1" aria-label="Default select example">
        <option disabled <?php echo e($leads->room_type ? '' : 'selected'); ?>>Open this select menu</option>
        <?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($rooms->id); ?>" <?php echo e($leads->room_type == $rooms->id ? 'selected' : ''); ?>>
                <?php echo e($rooms->room_type); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Addons</label>
    <select class="form-select" name="purpose" id="exampleFormControlSelect1" aria-label="Default select example">
        <option disabled <?php echo e($leads->extra_id ? '' : 'selected'); ?>>Open this select menu</option>
        <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ad->id); ?>" <?php echo e($leads->extra_id == $ad->id ? 'selected' : ''); ?>>
                <?php echo e($ad->extras); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
 <div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Lead Status</label>
    <select class="form-select" name="status" id="exampleFormControlSelect1" aria-label="Default select example">
        <option value="" disabled <?php echo e(is_null($leads->status) ? 'selected' : ''); ?>>Open this select menu</option>
        <option value="1" <?php echo e($leads->status == 1 ? 'selected' : ''); ?>>Hot</option>
        <option value="2" <?php echo e($leads->status == 2 ? 'selected' : ''); ?>>Warm</option>
        <option value="3" <?php echo e($leads->status == 3 ? 'selected' : ''); ?>>Cold</option>
    </select>
</div>
                        <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Booking Status</label>
                     
                        <select class="form-select" name="sales_status" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" disabled <?php echo e(is_null($leads->sale_status) ? 'selected' : ''); ?>>Open this select menu</option>
        <option value="1" <?php echo e($leads->sale_status == 1 ? 'selected' : ''); ?>>Converted</option>
        <option value="2" <?php echo e($leads->sale_status == 2 ? 'selected' : ''); ?>>Proccessing</option>
        <option value="3" <?php echo e($leads->sale_status == 3 ? 'selected' : ''); ?>>Dead</option>
                   </select>
                        
                      </div>
                      <div class="mb-3">
    <label for="exampleFormControlSelect1" class="form-label">Task Status</label>
    <select class="form-select" name="task_status" id="exampleFormControlSelect1" aria-label="Default select example">
        <option value="" disabled <?php echo e(is_null($leads->task_status) ? 'selected' : ''); ?>>Open this select menu</option>
        <option value="1" <?php echo e($leads->task_status == 1 ? 'selected' : ''); ?>>Pending</option>
        <option value="2" <?php echo e($leads->task_status == 2 ? 'selected' : ''); ?>>Completed</option>
    </select>
</div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Reminder Date</label>
                        <input
                          type="date"
                          name="reminder_date"
                          class="form-control"
                          value="<?php echo e($leads->reminder_date ?? ''); ?>"

                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Reminder Notes</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="note"><?php echo e($leads->note ?? ''); ?>

                        </textarea>
                      </div>
                      
                    
                      <div>
                      <button type="submit" class="btn btn-primary">Edit Lead</button>
                      </div>
</form>
                    </div>
                  </div>
                </div>

                <!-- Input Sizing -->
                

                <!-- Default Checkboxes and radios & Default checkboxes and radios -->
                

                
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\s_crm\resources\views/admin/leadedit.blade.php ENDPATH**/ ?>