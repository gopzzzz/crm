

<?php $__env->startSection('content'); ?>


<div class="container" style="max-width: 600px;">
        <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light">Home /</span> Add Reminder
    </h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <?php echo e($message); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <h5 class="card-header">Add Reminder</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('reminderstore')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
<input type="hidden" name="lead_id" value="<?php echo e($id); ?>">

                        <div class="row">
                            <div class="col-md-12">
                                <label class="form-label">Reminder Date</label>
                                <input type="date" class="form-control" name="reminder_date"  required>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Reminder Note</label>
                                <textarea  class="form-control" name="reminder_note" value="Enter Reminder Note"></textarea>
                            </div>
                        </div>
                        </div>


               <div class="text-end">
    <button type="submit" class="btn btn-primary mb-3 me-3">Add Reminder</button>
</div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRM\resources\views/admin/reminderadd.blade.php ENDPATH**/ ?>