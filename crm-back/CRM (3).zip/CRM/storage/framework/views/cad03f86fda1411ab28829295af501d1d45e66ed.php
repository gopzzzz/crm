

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Home /</span> Reminder
        </h4>

        <!-- Sort Link Helper -->
        
        <!-- Reminder Table -->
         <div class="app-content">
        <div class="container-fluid">
   
<?php if($role == 1): ?>
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0">Filters</h6>
    </div>

    <div class="collapse show" id="filterOptions">
        <div class="card-body">
            <form method="GET" action="<?php echo e(url()->current()); ?>" id="autoFilterForm" class="row gx-3 gy-2 align-items-end">

                
                <div class="col-md-2">
                    <label class="form-label form-label-sm mb-1">Lead Type</label>
                    <select name="source" class="form-select form-select-sm auto-submit">
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $leadTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>" <?php echo e(request('source') == $type->id ? 'selected' : ''); ?>>
                                <?php echo e($type->lead_type); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label form-label-sm mb-1">Created At</label>
                    <input type="date" name="created_at" class="form-control form-control-sm auto-submit" value="<?php echo e(request('created_at')); ?>">
                </div>

                
                <div class="col-md-2">
                    <label class="form-label form-label-sm mb-1">Assigned User</label>
                    <select name="assign_user" class="form-select form-select-sm auto-submit">
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($staff->userid); ?>" <?php echo e(request('assign_user') == $staff->userid ? 'selected' : ''); ?>>
                                <?php echo e($staff->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label form-label-sm mb-1">Status</label>
                    <select name="status" class="form-select form-select-sm auto-submit">
                        <option value="">-- Select --</option>
                        <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Hot</option>
                        <option value="2" <?php echo e(request('status') == '2' ? 'selected' : ''); ?>>Warm</option>
                        <option value="3" <?php echo e(request('status') == '3' ? 'selected' : ''); ?>>Cold</option>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label class="form-label form-label-sm mb-1">Sale Status</label>
                    <select name="sale_status" class="form-select form-select-sm auto-submit">
                        <option value="">-- Select --</option>
                        <option value="1" <?php echo e(request('sale_status') == '1' ? 'selected' : ''); ?>>Converted</option>
                        <option value="2" <?php echo e(request('sale_status') == '2' ? 'selected' : ''); ?>>Processing</option>
                        <option value="3" <?php echo e(request('sale_status') == '3' ? 'selected' : ''); ?>>Dead</option>
                    </select>
                </div>

            </form>
        </div>
    </div>
</div>

<?php endif; ?>

 
            <div class="card">
                
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Reminders</h3>
                    <div class="w-25">
                        <input type="text" id="search" name="search" placeholder="Search leads..." class="form-control" value="<?php echo e(request('search')); ?>">
                    </div>
                </div>

                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>WhatsApp</th>
                                <th>Lead ID</th>
                                <th>Lead Type</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Created At</th>
                                <th>Assigned User</th>
                                <th>Status</th>
                                <th>Sales Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <a href="https://wa.me/91<?php echo e($key->phone_number); ?>" target="_blank" title="WhatsApp">
                                        <i class="fab fa-whatsapp text-success fs-5"></i>
                                    </a>
                                </td>
                                <td><?php echo e($key->id); ?></td>
                                <td><strong><?php echo e($key->lead_type_name); ?></strong></td>
                                <td><?php echo e($key->full_name); ?></td>
                                <td><?php echo e($key->phone_number); ?></td>
                                <td><?php echo e($key->created_at ? \Carbon\Carbon::parse($key->created_at)->format('d-m-Y') : ''); ?></td>
                                <td><?php echo e($key->name); ?></td>
                                <td>
                                    <?php $statusClasses = [1 => 'success', 2 => 'warning', 3 => 'danger']; ?>
                                    <?php if(isset($statusClasses[$key->status])): ?>
                                        <span class="badge bg-<?php echo e($statusClasses[$key->status]); ?>">
                                            <?php echo e(['Hot', 'Warm', 'Cold'][$key->status - 1]); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php switch($key->sale_status):
                                        case (1): ?>
                                            <span class="badge bg-success">Converted</span>
                                            <?php break; ?>
                                        <?php case (2): ?>
                                            <span class="badge bg-warning">Processing</span>
                                            <?php break; ?>
                                        <?php case (3): ?>
                                            <span class="badge bg-danger">Dead</span>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <span class="badge bg-primary">Pending</span>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('leadedit', ['leadId' => $key->id])); ?>" target="_blank" class="text-primary" title="Edit">
                                        <i class="fa fa-pencil-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer clearfix">
                    <div class="float-end">
                        
                        <?php echo e($leads->appends(request()->query())->links()); ?>

                    </div>
                </div>

                
            </div>
        </div>
    </div>

    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('autoFilterForm');

        // Clear filters on initial load
        if (performance.navigation.type === 1 || performance.getEntriesByType("navigation")[0].type === "reload") {
            // Clear inputs and selects
            form.querySelectorAll('input, select').forEach(el => {
                el.value = '';
            });

            // Submit the form with cleared values
            form.submit();
        }

        // Auto-submit on filter change
        document.querySelectorAll('.auto-submit').forEach(function (element) {
            element.addEventListener('change', function () {
                form.submit();
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRM\resources\views/admin/notifications.blade.php ENDPATH**/ ?>