

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Reminder </h4>

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header"> Reminder</h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                  <?php
  function sort_link($field, $label, $currentField, $currentDir) {
      $dir = ($currentField === $field && $currentDir === 'asc') ? 'desc' : 'asc';
      $arrow = ($currentField === $field) ? ($currentDir === 'asc' ? '↑' : '↓') : '';
      return "<a href='?sort_by={$field}&sort_dir={$dir}'>{$label} {$arrow}</a>";
  }
?>

<thead>
  <tr>
    <th>#</th>
    <th>Lead Type</th>
    <th>Name</th>
    <th>Phone Number</th>
    <th>Check In</th>
    <th>Check Out</th>
    <!-- <th>Number Of Guest</th> -->
    <th>Status</th>
    <th>Sales Status</th>
  </tr>
</thead>

                    <tbody class="table-border-bottom-0">
                      <?php 
                      $i=1;
                      ?>
                      <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($key->lead_type_name); ?></strong></td>
                        <td><?php echo e($key->full_name); ?></td>
                        <td><?php echo e($key->phone_number); ?></td>
                        <td>
                        <?php echo e($key->checkin); ?>

                        </td>
                        <td>
                        <?php echo e($key->checkout); ?>

                        </td>
                      
                        <!-- <td>
                        Adult : <?php echo e($key->numberofguest); ?> <br>
                        Children : <?php echo e($key->child); ?> <br>
                        Infants : <?php echo e($key->infant); ?> 
                        </td> -->
                       
                        <td><?php if($key->status==1): ?><span class="badge bg-danger me-1">Hot</span> <?php elseif($key->status==2): ?> <span class="badge bg-label-warning me-1">Warm</span> <?php else: ?> <span class="badge bg-success me-1">Cold</span> <?php endif; ?></td>
                        <td><?php if($key->sale_status==1): ?><span class="badge bg-success me-1">Converted</span> <?php elseif($key->sale_status==2): ?> <span class="badge bg-label-warning me-1">Proccessing</span> <?php else: ?> <span class="badge bg-danger me-1">Dead</span> <?php endif; ?></td>
                      
                        <td>
                        <a href="<?php echo e(route('leadedit', ['leadId' => $key->id ])); ?>" class="btn btn-outline-primary btn-lg leadedit" target="_blank">Edit</a>
                        </td>
                      </tr>
                      <?php 
                      $i++;
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="buy-now">
      <a href="<?php echo e(url('addlead')); ?>" class="btn btn-danger btn-buy-now">ADD LEAD</a>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/softotql/data.softocoder.com/resources/views/admin/notifications.blade.php ENDPATH**/ ?>