

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Add Leads</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="row">
                <!-- Form controls -->
                <div class="col-md-6">
                  <div class="card mb-4">
                    <h5 class="card-header">Register New Enquiries</h5>
                    <div class="card-body">
                    <form action="<?php echo e(route('createnewlead')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                    <label for="exampleFormControlSelect1" class="form-label"> Lead Type<small>
                     <span class="text-danger fw-bold" style="font-size: 1.2em;">*</span>
                    </small>
                         </label>

                        <select class="form-select" name="leadtype" id="exampleFormControlSelect1" aria-label="Default select example">
                          <option selected>Open this select menu</option>
                          <?php $__currentLoopData = $leadtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($type->id); ?>"><?php echo e($type->lead_type); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                        <input
                          type="text"
                          class="form-control"
                          id="exampleFormControlInput1"
                          placeholder="Enter your name"
                          name="fullname"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInput1" class="form-label">Email</label>
                        <input
                          class="form-control"
                          type="email"
                          id="exampleFormControlReadOnlyInput1"
                          placeholder="example@gmail.com"
                          name="email"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Phone Number<small>
                     <span class="text-danger fw-bold" style="font-size: 1.2em;">*</span>
                    </small></label>
                        <input
                          type="number"
                          name="phonenumber"
                          class="form-control"
                          placeholder="Enter your phone number"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                    <label for="exampleFormControlSelect1" class="form-label">Assigned User
                         </label>

                        <select class="form-select" name="assigneduser" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($typee->userid); ?>"><?php echo e($typee->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Check In</label>
                        <input
                          type="date"
                          name="checkin"
                          class="form-control"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Check Out</label>
                        <input
                          type="date"
                          name="checkout"
                          class="form-control"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      <div class="mb-3">
  <label class="form-label">Number of Guests</label>
  
  <div class="row">
    <div class="col">
      <input
        name="adults"
        type="number"
        class="form-control"
        placeholder="Adults"
        min="0"
      />
    </div>
    <div class="col">
      <input
        name="children"
        type="number"
        class="form-control"
        placeholder="Children"
        min="0"
      />
    </div>
    <div class="col">
      <input
        name="infants"
        type="number"
        class="form-control"
        placeholder="Infants"
        min="0"
      />
    </div>
  </div>
</div>
                      <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Room Type</label>
                        <select class="form-select" name="roomtype" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                        <?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($rooms->id); ?>"><?php echo e($rooms->room_type); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>

                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Addons</label>
                     
                        <select class="form-select" name="purpose" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                        <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($ad->id); ?>"><?php echo e($ad->extras); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Lead Status</label>
                     
                        <select class="form-select" name="status" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          
                          <option value="1">Hot</option>
                          <option value="2">Warm</option>
                          <option value="3">Cold</option>
                        </select>
                        
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Booking Status</label>
                     
                        <select class="form-select" name="sales_status" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          
                          <option value="1">Converted</option>
                          <option value="2">Proccessing</option>
                          <option value="3">Dead</option>
                        </select>  
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Task Status</label>
                     
                        <select class="form-select" name="task_status" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                           <option value="1">Pending</option>
                          <option value="2">Completed</option>
                      
                        </select>  
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlReadOnlyInputPlain1" class="form-label">Reminder Date</label>
                        <input
                          type="date"
                          name="reminder_date"
                          class="form-control"
                          id="exampleFormControlReadOnlyInputPlain1"
                         
                        />
                      </div>
                      
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Reminder Notes</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="note"></textarea>
                      </div>
                      
                    
                      <div>
                      <button type="submit" class="btn btn-primary">Create New Lead</button>
                      </div>
</form>
                    </div>
                  </div>
                </div>

                <!-- Input Sizing -->
                

                <!-- Default Checkboxes and radios & Default checkboxes and radios -->
                

                
              </div>
            </div>



            

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PANTRYCARCRM\resources\views/admin/addlead.blade.php ENDPATH**/ ?>