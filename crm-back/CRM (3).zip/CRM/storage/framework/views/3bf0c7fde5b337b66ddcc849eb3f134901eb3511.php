

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Home /</span> Employees
        </h4>

        <!-- Add Employee Button -->
        <div class="mb-3 text-end">
            <a href="<?php echo e(url('addemployee')); ?>" class="btn btn-primary">Add Employee</a>
        </div>

        <!-- Employee Table -->
        <div class="card">
            <h5 class="card-header">All Employees</h5>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Designation</th>
                            <th>Phone Number</th>
                            <th>Email Address</th>
                            <th>Address</th>
                            <th>Date of Birth</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-2"></i>
                                <strong><?php echo e($employee->name); ?></strong>
                            </td>
                            <td><?php echo e($employee->designation); ?></td>
                            <td><?php echo e($employee->phone_number); ?></td>
                            <td><?php echo e($employee->email); ?></td>
                            <td><?php echo e($employee->address); ?></td>
                            <td><?php echo e($employee->dob); ?></td>
                            <td><?php if($employee->status==0): ?> ACTIVE <?php elseif($employee->status==1): ?> INACTIVE <?php endif; ?></td>

                            <td>
                                <a href="<?php echo e(route('employeeedit', ['employeeId' => $employee->id])); ?>" class="text-primary me-2">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRM\resources\views/employee/employeelist.blade.php ENDPATH**/ ?>