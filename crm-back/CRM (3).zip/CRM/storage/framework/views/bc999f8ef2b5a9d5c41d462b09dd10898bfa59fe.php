

<?php $__env->startSection('content'); ?>




<div class="content-wrapper">

<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->



            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Addons</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


              <div class="row">
                <div class="col-md-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Addons  </h5>
                    <div class="card-body">
                      <div>
                      <form action="<?php echo e(route('add_addons')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                        <label for="defaultFormControlInput" class="form-label">Addons </label>
                        <input
                          type="text"
                          class="form-control"
                          id="defaultFormControlInput"
                          placeholder="Enter Extra features"
                          aria-describedby="defaultFormControlHelp"

                          name="type"
                        />
                        <br>
                       
                        <button type="submit" class="btn btn-outline-primary">Create Addons</button>
                     
                       </form>
                      </div>
                    </div>
                  </div>
                </div>
               


              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header">Addons </h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Addon</th>
                       
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php 
                        $i=1;
                        ?>
                      <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($key->extras); ?></td>
                        <td>
                     <button  type="button" class="btn btn-outline-primary edit_addon"  data-bs-toggle="modal" data-bs-target="#editaddonmodal"onclick="openEmptyAddonEditModal()" data-id="<?php echo e($key->id); ?>">
                     Edit 
                   </button>
                    </td>

                
                      </tr>
                      <?php 
                      $i++;
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </tbody>
                  </table>

  <div class="modal" id="editaddonmodal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Addon</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </button>
        
      </div>
      <form method="POST" action="<?php echo e(url('addonedit')); ?>" enctype="multipart/form-data" name="addonedit">

<?php echo csrf_field(); ?>
      <div class="modal-body row">
<input type="hidden" name="id" id="addonid">
<label for="defaultFormControlInput" class="form-label">Addons</label>
<input type="text" class="form-control" id="addon" placeholder="Enter Extra features" name="addon"/>

</div>
  <div class="modal-footer">
  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

     <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
</div>
                </div>
              </div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/softotql/data.softocoder.com/resources/views/admin/extras.blade.php ENDPATH**/ ?>