

<?php $__env->startSection('content'); ?>
<style>
  /* Status option text colors */
  select[name="status"] option[value="1"] { color: red; }        /* Not Started */
  select[name="status"] option[value="2"] { color: orange; }     /* Started */
  select[name="status"] option[value="3"] { color: green; }      /* Completed */
  select[name="status"] option[value="4"] { color: gray; }       /* Canceled */
  select[name="status"] option[value="5"] { color: blue; }       /* Deferred */

  /* Priority option text colors */
  select[name="priority"] option[value="1"] { color: gray; }     /* Low */
  select[name="priority"] option[value="2"] { color: teal; }     /* Normal */
  select[name="priority"] option[value="3"] { color: orange; }   /* High */
  select[name="priority"] option[value="4"] { color: red; }      /* Urgent */
</style>


<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Add Tasks</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="row">
  <div class="col-md-10">
    <div class="card mb-4">
      <h5 class="card-header">Register New Tasks</h5>
      <div class="card-body">
        <form action="<?php echo e(route('createnewtask')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <!-- Lead & Assigned User -->
          <div class="row mb-3">
  <div class="col-md-6">
    <label for="leadSelect" class="form-label">Lead</label>
    <select class="form-select" name="lead" id="leadSelect">
      <option selected disabled>Open this select menu</option>
      <?php $__currentLoopData = $leadtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($type->id) && !empty($type->full_name)): ?>
          <option value="<?php echo e($type->id); ?>"><?php echo e($type->full_name); ?></option>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

            <div class="col-md-6">
              <label for="assignedUserSelect" class="form-label">Assigned User</label>
              <select class="form-select" name="assigneduser" id="assignedUserSelect">
                <option selected disabled>Open this select menu</option>
                <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($typee->id); ?>"><?php echo e($typee->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>

          <!-- Task Date & Status -->
          <div class="row mb-3">
            <div class="col-md-6">
              <label for="taskDate" class="form-label">Task Created Date</label>
              <input type="date" name="task_date" class="form-control" id="taskDate" />
            </div>
            <div class="col-md-6">
              <label for="statusSelect" class="form-label">Status</label>
              <select class="form-select" name="status" id="statusSelect">
                <option value="" selected disabled>Open this select menu</option>
                <option value="1">Not Started</option>
                <option value="2">Started</option>
                <option value="3">Completed</option>
                <option value="4">Canceled</option>
                <option value="5">Deferred</option>
              </select>
            </div>
          </div>

          <!-- Priority & Start Date -->
          <div class="row mb-3">
            <div class="col-md-6">
              <label for="prioritySelect" class="form-label">Priority</label>
              <select class="form-select" name="priority" id="prioritySelect">
                <option value="" selected disabled>Open this select menu</option>
                <option value="1">Low</option>
                <option value="2">Normal</option>
                <option value="3">High</option>
                <option value="4">Urgent</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="startDate" class="form-label">Start Date</label>
              <input type="date" name="start_date" class="form-control" id="startDate" />
            </div>
          </div>

          <!-- Due Date & Notes -->
          <div class="row mb-3">
            <div class="col-md-6">
              <label for="dueDate" class="form-label">Due Date</label>
              <input type="date" name="due_date" class="form-control" id="dueDate" />
            </div>
            <div class="col-md-6">
              <label for="notesTextarea" class="form-label">Notes</label>
              <textarea class="form-control" id="notesTextarea" rows="3" name="notes"></textarea>
            </div>
      
            <div class="text-end mt-3">
  <button type="submit" class="btn btn-primary ">Create New Task</button>
</div>
                      </div>
</form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\s_crm\resources\views/addtask.blade.php ENDPATH**/ ?>