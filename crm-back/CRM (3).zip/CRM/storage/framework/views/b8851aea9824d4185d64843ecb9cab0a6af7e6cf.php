

<?php $__env->startSection('content'); ?>
<div class="pc-container">
    <div class="pc-content">
      <!-- [ breadcrumb ] start -->
      <div class="page-header">
        <div class="page-block">
          <div class="row align-items-center">
            <div class="col-md-12">
           
              <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('agent')); ?>">Agent Registration</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('agentlist')); ?>">Agent List</a></li>
            
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
          <!-- [ form-element ] start -->
          <div class="col-sm-12">
            <div class="card">
              <div class="card-header">
                <h5>Agent List</h5>
              
              </div>
              <div class="card-body">
                <div class="dt-responsive table-responsive">
                  <table id="simpletable" class="table table-striped table-bordered nowrap">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>State</th>
                        <th>District</th>
                        <th>Place</th>
                        <th>Joing Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $agentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key->name); ?></td>
                        <td><?php echo e($key->phone_number); ?></td>
                        <td>Kerala</td>
                        <td><?php echo e($key->district_name); ?></td>
                        <td><?php echo e($key->address); ?></td>
                        <td><?php echo e($key->join_date); ?></td>
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                      <tr>
                      <th>Name</th>
                        <th>Phone Number</th>
                        <th>State</th>
                        <th>District</th>
                        <th>Place</th>
                        <th>Joing Date</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!-- [ form-element ] end -->
        </div>

      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\silver_woods\resources\views/agent/agentlist.blade.php ENDPATH**/ ?>