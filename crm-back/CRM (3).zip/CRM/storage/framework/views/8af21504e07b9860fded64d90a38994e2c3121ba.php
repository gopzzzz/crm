

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Employees </h4>

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header">All Employees</h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                       <th>#</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Phone Number</th>
                        <th>Email Address</th>
                        <th>Address</th>
                       
                        <th>Date of Birth</th>
                        
                        <th></th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php 
                      $i=1;
                      ?>
                      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($key->name); ?></strong></td>
                        <td><?php echo e($key->designation); ?></td>
                        <td><?php echo e($key->phone_number); ?></td>
                        <td> <?php echo e($key->email); ?></td>
                        <td><?php echo e($key->address); ?></td>
                        <td><?php echo e($key->dob); ?> </td>
                        </td> 
                        <td>
                        <a href="<?php echo e(route('employeeedit', ['employeeId' => $key->id ])); ?>" >  <i class="fa fa-pencil-alt employeeedit"></i></a>
                        </td>
                        </tr>
                      <?php 
                      $i++;
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      
                    </tbody>
                  </table>
                  <div class="buy-now">
      <a href="<?php echo e(url('addemployee')); ?>" class="btn btn-danger btn-buy-now">ADD EMPLOYEE</a>
    </div>
                </div>
              </div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PANTRYCARCRM\resources\views/employee/employeelist.blade.php ENDPATH**/ ?>