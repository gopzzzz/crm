<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
      <div class="row">
        <div class="col-sm my-1">
          <p class="m-0"
            >Silver Woods  &#9829; crafted by Team <a href="https://routeqinnovations.in" target="_blank">Routeq Innovations</a></p
          >
        </div>
        <div class="col-auto my-1">
          <ul class="list-inline footer-link mb-0">
            <li class="list-inline-item"><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
<?php /**PATH C:\xampp\htdocs\silver_woods\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>