

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
            <!-- Content -->
        
            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Leads </h4>
              <!-- <a href="<?php echo e(url('addtask')); ?>" class="btn btn-danger btn-buy-now" target="_blank">Create Task</a> -->

              <div class="d-flex justify-content-end p-3">
    <input type="text"   id="search" placeholder="Search leads..." class="form-control" autocomplete="off" value="<?php echo e($searchQuery ?? ''); ?>" style="width: 300px;">
</div>
<td>
                        </td>
              <div class="card">
                  <!-- Basic Bootstrap Table -->
                  <div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0"></h5>
        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#filterOptions" aria-expanded="false" aria-controls="filterOptions">
            Toggle Filter
        </button>
    </div>
    <div class="collapse show" id="filterOptions">
        <div class="card-body">
        <form method="GET" action="<?php echo e(url()->current()); ?>" class="row g-3" id="autoFilterForm">
    <div class="col-md-2">
        <select name="source" class="form-control auto-submit">
            <option value="">-- Source --</option>
            <?php $__currentLoopData = $leadTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type->id); ?>" <?php echo e(request('source') == $type->id ? 'selected' : ''); ?>>
                    <?php echo e($type->lead_type); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-2 form-floating">
        <input type="date" id="checkin" name="checkin" class="form-control auto-submit"
               placeholder="Check-in" value="<?php echo e(request('checkin')); ?>">
        <label for="checkin">Check-in</label>
    </div>

    <div class="col-md-2 form-floating">
        <input type="date" id="checkout" name="checkout" class="form-control auto-submit"
               placeholder="Check-out" value="<?php echo e(request('checkout')); ?>">
        <label for="checkout">Check-out</label>
    </div>

    <?php if($role==1): ?>

    <div class="col-md-2">
        <select name="assign_user" class="form-control auto-submit">
            <option value="">-- Assigned User --</option>
            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($staff->id); ?>" <?php echo e(request('assign_user') == $staff->id ? 'selected' : ''); ?>>
                    <?php echo e($staff->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <?php endif; ?>

    <div class="col-md-2">
        <select name="status" class="form-control auto-submit">
            <option value="">-- Status --</option>
            <option value="1" <?php echo e(request('status') == 1 ? 'selected' : ''); ?>>Hot</option>
            <option value="2" <?php echo e(request('status') == 2 ? 'selected' : ''); ?>>Warm</option>
            <option value="3" <?php echo e(request('status') == 3 ? 'selected' : ''); ?>>Cold</option>
        </select>
    </div>

    <div class="col-md-2">
        <select name="sale_status" class="form-control auto-submit">
            <option value="">-- Sale Status --</option>
            <option value="1" <?php echo e(request('sale_status') == 1 ? 'selected' : ''); ?>>Converted</option>
            <option value="2" <?php echo e(request('sale_status') == 2 ? 'selected' : ''); ?>>Processing</option>
            <option value="3" <?php echo e(request('sale_status') == 3 ? 'selected' : ''); ?>>Dead</option>
        </select>
    </div>

  
    <div class="col-md-2 form-floating">
        <input type="date" id="created_from" name="created_from" class="form-control auto-submit"
               value="<?php echo e(request('created_from')); ?>">
        <label for="created_from">Created From</label>
    </div>

    <div class="col-md-2 form-floating">
        <input type="date" id="created_to" name="created_to" class="form-control auto-submit"
               value="<?php echo e(request('created_to')); ?>">
        <label for="created_to">Created To</label>
    </div>
</form>

        </div>
    </div>
</div>

 <h5 class="card-header">All Leads</h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                  <?php
    if (!function_exists('sortLink')) {
        function sortLink($column, $label, $sortBy, $sortDirection)
        {
            $direction = ($sortBy === $column && $sortDirection === 'asc') ? 'desc' : 'asc';
            $icon = '';

            if ($sortBy === $column) {
                $icon = $sortDirection === 'asc' ? '↑' : '↓';
            }

            $query = request()->query();
            $query['sort_by'] = $column;
            $query['sort_direction'] = $direction;

            $url = url()->current() . '?' . http_build_query($query);

            return '<a href="' . $url . '">' . $label . ' ' . $icon . '</a>';
        }
    }
?>
<thead>
<tr>
    <th>#</th>
    <th>Lead ID</th>
    <th><?php echo sortLink('lead_type_name', 'Source', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('full_name', 'Name', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('phone_number', 'Phone Number', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('checkin', 'Check In', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('checkout', 'Check Out', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('created_at', 'Created At', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('name', 'Assigned User', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('status', 'Status', $sortBy, $sortDirection); ?></th>
    <th><?php echo sortLink('sale_status', 'Sale Status', $sortBy, $sortDirection); ?></th>
</tr>
</thead>
  <tbody class="table-border-bottom-0" id="leadTableBody">
                    <?php 
                      $i=1;
                      ?>
                      <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>

                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($key->id); ?></td>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($key->lead_type_name); ?></strong></td>
                        <td><?php echo e($key->full_name); ?></td>
                        <td><?php echo e($key->phone_number); ?></td>
                        <td>
                        <?php echo e($key->checkin ? \Carbon\Carbon::parse($key->checkin)->format('m-Y-d') : ''); ?>

                        </td>
                        <td>
                        <?php echo e($key->checkout ? \Carbon\Carbon::parse($key->checkout)->format('m-Y-d') : ''); ?>

                        </td>
                        <td><?php echo e($key->created_at ? \Carbon\Carbon::parse($key->created_at)->format('m-Y-d') : ''); ?></td>

                        <td>
                        <?php echo e($key->name); ?>

                        </td>
                        <td>
                          <?php if($key->status == 1): ?>
                        <span class="badge bg-success me-1">Hot</span>
                        <?php elseif($key->status == 2): ?>
                        <span class="badge bg-label-warning me-1">Warm</span>
                        <?php elseif($key->status == 3): ?>
                        <span class="badge bg-danger me-1">Cold</span>
                        <?php else: ?>
                        <span class="badge bg-secondary me-1"></span> 
                        <?php endif; ?>
                        </td>

                        <td>
                         <?php if($key->sale_status == 1): ?>
                         <span class="badge bg-success me-1">Converted</span>
                         <?php elseif($key->sale_status == 2): ?>
                         <span class="badge bg-label-warning me-1">Processing</span>
                          <?php elseif($key->sale_status == 3): ?>
                          <span class="badge bg-danger me-1">Dead</span>
                          <?php elseif($key->sale_status == 0 || $key->sale_status==NULL): ?>
                         <span class="badge bg-label-primary me-1">Pending</span>
                          <?php else: ?>
                          <span class="badge bg-secondary me-1"></span> 
                          <?php endif; ?>
                         </td>
                        <td class="d-none">
                        <?php echo e($key->email); ?>

                         <?php echo e($key->note); ?>

                         <?php echo e($key->reminder_date); ?>

                         <?php echo e($key->extras); ?>

                         <?php echo e($key->room_type); ?>

                         </td>
  <td>
   <a href="<?php echo e(route('leadedit', ['leadId' => $key->id ])); ?>" class="btn btn-outline-primary btn-lg leadedit" target="_blank">Edit</a>
                        </td>
                      </tr>
                      <?php 
                      $i++;
                      ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                
                  </table>
                </div>
              </div>
        

              <div class="buy-now">
      <a href="<?php echo e(url('addlead')); ?>" class="btn btn-danger btn-buy-now">ADD LEAD</a>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function () {
    $('#search').on('keyup', function () {
        var searchText = $(this).val().toLowerCase();
        $('#leadTableBody tr').each(function () {
            var rowText = $(this).text().toLowerCase();
            $(this).toggle(rowText.includes(searchText));
        });
    });
});
</script>
<script>
    document.querySelectorAll('.auto-submit').forEach(function(element) {
        element.addEventListener('change', function() {
            document.getElementById('autoFilterForm').submit();
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\s_crm\resources\views/admin/leadslist.blade.php ENDPATH**/ ?>