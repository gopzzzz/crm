  <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <!-- Page JS -->
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
<script>
    $(document).on('click', '.edit_addon', function () {
    var id = $(this).data('id');
    if(id){
      $.ajax({
					type: "POST",
          url: "<?php echo e(route('addonfetch')); ?>",
					data: {  "_token": "<?php echo e(csrf_token()); ?>",
					id: id },
					success: function (res) {
					console.log(res);
          var obj=JSON.parse(res)
		      $('#addonid').val(obj.id); 
          $('#addon').val(obj.extras);
		
					},
					});	
		}
		$('#editaddon_modal').modal('show');
	});
  $(document).on('click', '.close, .btn-secondary', function () {
    $('#editaddon_modal').modal('hide');
});

$(document).on('click', '.edit_leadtype', function () {
    var id = $(this).data('id');
    if(id){
      $.ajax({
					type: "POST",
          url: "<?php echo e(route('leadtypefetch')); ?>",
					data: {  "_token": "<?php echo e(csrf_token()); ?>",
					id: id },
					success: function (res) {
					console.log(res);
          var obj=JSON.parse(res)
		      $('#leadtypeid').val(obj.id); 
          $('#leadtype').val(obj.lead_type);
		
					},
					});	
		}
		$('#editleadtype_modal').modal('show');
	});
  $(document).on('click', '.close, .btn-secondary', function () {
    $('#editleadtype_modal').modal('hide');
});

$(document).on('click', '.edit_roomtype', function () {
    var id = $(this).data('id');
    if(id){
      $.ajax({
					type: "POST",
          url: "<?php echo e(route('roomtypefetch')); ?>",
					data: {  "_token": "<?php echo e(csrf_token()); ?>",
					id: id },
					success: function (res) {
					console.log(res);
          var obj=JSON.parse(res)
		      $('#roomtypeid').val(obj.id); 
          $('#roomtype').val(obj.room_type);
		
					},
					});	
		}
		$('#editroomtype_modal').modal('show');
	});
  $(document).on('click', '.close, .btn-secondary', function () {
    $('#editroomtype_modal').modal('hide');
});
</script>

    <?php /**PATH C:\xampp\htdocs\s_crm\resources\views/layouts/partials/footer-scripts.blade.php ENDPATH**/ ?>