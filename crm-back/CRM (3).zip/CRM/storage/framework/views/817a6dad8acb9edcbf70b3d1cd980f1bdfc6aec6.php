

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home /</span> Assign Leads</h4>

              <?php if(session('success')): ?>
              
              <div class="alert alert-success alert-dismissible" role="alert">
              <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
      
    <?php endif; ?>

    
<?php if($errors->any()): ?>
    <div class="alert alert-warning">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__errorArgs = ['csv_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            


              <div class="row">
                <div class="col-md-6">
                  <div class="card mb-4">
                    <h5 class="card-header">Assign Leads</h5>
                    <div class="card-body">
                      <div>
                      <form action="<?php echo e(route('assignuser')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                        <label for="defaultFormControlInput" class="form-label">Employee Name</label>
                         <select class="form-select" name="assigneduser" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($typee->id); ?>"><?php echo e($typee->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                          <label for="defaultFormControlInput" class="form-label">Lead From</label>
                          <input
                          type="text"
                          class="form-control"
                          id="defaultFormControlInput"
                          placeholder="1"
                          aria-describedby="defaultFormControlHelp"

                          name="from"
                        />
                          <label for="defaultFormControlInput" class="form-label">Lead To</label>
                          <input
                          type="text"
                          class="form-control"
                          id="defaultFormControlInput"
                          placeholder="10"
                          aria-describedby="defaultFormControlHelp"

                          name="to"
                        />
                        <br>
                        <button type="submit" class="btn btn-outline-primary">Assign</button>
                     
                       </form>
                      </div>
                    </div>
                  </div>
                </div>
               <div class="col-md-6">
                  <div class="card mb-4">
                    <h5 class="card-header">Reasign Leads</h5>
                    <div class="card-body">
                      <div>
                      <form action="<?php echo e(route('reasignuser')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                        <label for="defaultFormControlInput" class="form-label">Employee From</label>
                          <select class="form-select" name="userfrom" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($typee->id); ?>"><?php echo e($typee->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                          <label for="defaultFormControlInput" class="form-label">Employee To</label>
                          <select class="form-select" name="userto" id="exampleFormControlSelect1" aria-label="Default select example">
                        <option value="" selected disabled>Open this select menu</option>
                          <?php $__currentLoopData = $assigneduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($typee->id); ?>"><?php echo e($typee->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                        <br>
                       
                        <button type="submit" class="btn btn-outline-primary">Reassign</button>
                     
                       </form>
                      </div>
                    </div>
                  </div>
                </div>

              

                <!-- Input Sizing -->
                

                <!-- Default Checkboxes and radios & Default checkboxes and radios -->
                

                
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\s_crm\resources\views/admin/assignleads.blade.php ENDPATH**/ ?>