

<?php $__env->startSection('content'); ?>

<style>
  .pagination {
    justify-content: flex-end;
    margin-bottom: 0;
}
  </style>

<main class="app-main">
    <!-- Header -->
    <div class="app-content-header">
        <div class="container-fluid">
            <div class="row align-items-center mb-3">
                <div class="col-sm-6">
                    <h3 class="mb-0">Lead List</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Lead List</li>
                    </ol>
                </div>

                <div class="col-md-6">
                    <div>App Content Top Area</div>
                </div>

                <div class="col-md-6 text-end">
                    <a href="<?php echo e(url('addlead')); ?>">
                        <button type="button" class="btn btn-primary">Create Admin</button>
                    </a>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Filters</h5>
                    <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#filterOptions">
                        ALL FILTER
                    </button>
                </div>
                <div class="collapse show" id="filterOptions">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(url()->current()); ?>" class="row g-3" id="autoFilterForm">
                            <div class="col-md-2">
                                <select name="source" class="form-control auto-submit">
                                    <option value="">-- Source --</option>
                                    <?php $__currentLoopData = $leadTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>" <?php echo e(request('source') == $type->id ? 'selected' : ''); ?>>
                                            <?php echo e($type->lead_type); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-2 form-floating">
                                <input type="date" id="checkin" name="checkin" class="form-control auto-submit" value="<?php echo e(request('checkin')); ?>">
                                <label for="checkin">Check-in</label>
                            </div>

                            <div class="col-md-2 form-floating">
                                <input type="date" id="checkout" name="checkout" class="form-control auto-submit" value="<?php echo e(request('checkout')); ?>">
                                <label for="checkout">Check-out</label>
                            </div>

                            <?php if($role == 1): ?>
                            <div class="col-md-2">
                                <select name="assign_user" class="form-control auto-submit">
                                    <option value="">-- Assigned User --</option>
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($staff->userid); ?>" <?php echo e(request('assign_user') == $staff->userid ? 'selected' : ''); ?>>
                                            <?php echo e($staff->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <div class="col-md-2">
                                <select name="status" class="form-control auto-submit">
                                    <option value="">-- Status --</option>
                                    <option value="1" <?php echo e(request('status') == 1 ? 'selected' : ''); ?>>Hot</option>
                                    <option value="2" <?php echo e(request('status') == 2 ? 'selected' : ''); ?>>Warm</option>
                                    <option value="3" <?php echo e(request('status') == 3 ? 'selected' : ''); ?>>Cold</option>
                                </select>
                            </div>

                            <div class="col-md-2">
                                <select name="sale_status" class="form-control auto-submit">
                                    <option value="">-- Sale Status --</option>
                                    <option value="1" <?php echo e(request('sale_status') == 1 ? 'selected' : ''); ?>>Converted</option>
                                    <option value="2" <?php echo e(request('sale_status') == 2 ? 'selected' : ''); ?>>Processing</option>
                                    <option value="3" <?php echo e(request('sale_status') == 3 ? 'selected' : ''); ?>>Dead</option>
                                </select>
                            </div>

                            <div class="col-md-2 form-floating">
                                <input type="date" id="created_from" name="created_from" class="form-control auto-submit" value="<?php echo e(request('created_from')); ?>">
                                <label for="created_from">Created From</label>
                            </div>

                            <div class="col-md-2 form-floating">
                                <input type="date" id="created_to" name="created_to" class="form-control auto-submit" value="<?php echo e(request('created_to')); ?>">
                                <label for="created_to">Created To</label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Table Section -->
    <div class="app-content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Lead List</h3>
                    <div class="w-25">
                        <input type="text" id="search" name="search" placeholder="Search leads..." class="form-control" value="<?php echo e(request('search')); ?>">
                    </div>
                </div>

                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>WhatsApp</th>
                                <th>Lead ID</th>
                                <th>Lead Type</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Created At</th>
                                <th>Assigned User</th>
                                <th>Status</th>
                                <th>Sales Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <a href="https://wa.me/91<?php echo e($key->phone_number); ?>" target="_blank" title="WhatsApp">
                                        <i class="fab fa-whatsapp text-success fs-5"></i>
                                    </a>
                                </td>
                                <td><?php echo e($key->id); ?></td>
                                <td><strong><?php echo e($key->lead_type_name); ?></strong></td>
                                <td><?php echo e($key->full_name); ?></td>
                                <td><?php echo e($key->phone_number); ?></td>
                                <td><?php echo e($key->created_at ? \Carbon\Carbon::parse($key->created_at)->format('d-m-Y') : ''); ?></td>
                                <td><?php echo e($key->name); ?></td>
                                <td>
                                    <?php $statusClasses = [1 => 'success', 2 => 'warning', 3 => 'danger']; ?>
                                    <?php if(isset($statusClasses[$key->status])): ?>
                                        <span class="badge bg-<?php echo e($statusClasses[$key->status]); ?>">
                                            <?php echo e(['Hot', 'Warm', 'Cold'][$key->status - 1]); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php switch($key->sale_status):
                                        case (1): ?>
                                            <span class="badge bg-success">Converted</span>
                                            <?php break; ?>
                                        <?php case (2): ?>
                                            <span class="badge bg-warning">Processing</span>
                                            <?php break; ?>
                                        <?php case (3): ?>
                                            <span class="badge bg-danger">Dead</span>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <span class="badge bg-primary">Pending</span>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('leadedit', ['leadId' => $key->id])); ?>" target="_blank" class="text-primary" title="Edit">
                                        <i class="fa fa-pencil-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer clearfix">
                    <div class="float-end">
                        
                        <?php echo e($leads->appends(request()->query())->links()); ?>

                    </div>
                </div>

                
            </div>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function () {
    $('#search').on('keyup', function () {
      
        var searchText = $(this).val().toLowerCase();
        $('#leadTableBody tr').each(function () {
            var rowText = $(this).text().toLowerCase();
            $(this).toggle(rowText.includes(searchText));
        });
    });
});
</script>
<script>
    document.querySelectorAll('.auto-submit').forEach(function(element) {
        element.addEventListener('change', function() {
            document.getElementById('autoFilterForm').submit();
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/softotql/data.softocoder.com/resources/views/admin/leadslist.blade.php ENDPATH**/ ?>