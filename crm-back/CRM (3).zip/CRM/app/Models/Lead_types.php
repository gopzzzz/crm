<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lead_types extends Model
{
    use HasFactory;
    protected $fillable = ['lead_type'];

}
